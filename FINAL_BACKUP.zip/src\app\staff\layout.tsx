"use client";

import { Home, Plus, History, User, Settings } from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import { setupFirebaseSync, db } from "@/services/db";

export default function StaffLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const pathname = usePathname();
    const router = useRouter();
    const isActive = (path: string) => pathname === path;

    // Auth Check & Sync
    useEffect(() => {
        const session = localStorage.getItem('payment_app_session');
        if (session !== 'staff') {
            router.push('/');
        }
        // Start Sync
        setupFirebaseSync();

        // Heartbeat for Online Status
        const userStr = localStorage.getItem('payment_app_user');
        if (userStr) {
            try {
                const user = JSON.parse(userStr);
                if (user && user.id) {
                    // Initial update
                    db.updateStaffLastSeen(user.id);

                    // Periodic update every 30 seconds
                    const interval = setInterval(() => {
                        db.updateStaffLastSeen(user.id);
                    }, 30000);

                    return () => clearInterval(interval);
                }
            } catch (e) {
                console.error("Error parsing staff user for heartbeat", e);
            }
        }
    }, []);

    // Theme Initialization - Default to Dark Mode for Premium Feel
    useEffect(() => {
        const theme = localStorage.getItem('theme');
        // Default to 'dark' if no preference is set, or if explicitly set to 'dark'
        // This matches the hardcoded dark styles of other tabs (History, etc.)
        const shouldBeDark = theme === 'dark' || !theme;

        if (shouldBeDark) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    }, []);

    // Notification Listener
    const [notifToast, setNotifToast] = useState('');
    useEffect(() => {
        const checkNotifs = () => {
            const list = db.getStaffNotifications();
            if (list && list.length > 0) {
                const latest = list[0];
                // Check if new (within last 5 seconds) to avoid spam on reload
                if (Date.now() - latest.timestamp < 5000) {
                    setNotifToast(latest.message);
                    setTimeout(() => setNotifToast(''), 5000);
                    // Can play sound here
                }
            }
        };

        window.addEventListener('staff-notif-updated', checkNotifs);
        window.addEventListener('storage', (e) => {
            if (e.key === 'staff_notifications_list') checkNotifs();
        });

        return () => {
            window.removeEventListener('staff-notif-updated', checkNotifs);
            window.removeEventListener('storage', checkNotifs); // storage event handler ref mismatch fixed by inline or careful ref
        };
    }, []);


    return (
        <div className="min-h-screen w-full bg-white dark:bg-[#0f1115] font-sans transition-colors duration-300 flex flex-col">
            {/* Main Content Area */}
            <main className="flex-1 overflow-y-auto scrollbar-hide bg-white dark:bg-[#0f1115] text-slate-900 dark:text-white relative pb-28 transition-colors duration-300">
                {children}
            </main>

            {/* Premium Floating Navigation */}
            <div className="fixed bottom-6 left-6 right-6 z-50">
                <nav className="h-16 bg-white/80 dark:bg-white/10 backdrop-blur-xl border border-slate-200 dark:border-white/10 rounded-3xl flex justify-between items-center px-2 shadow-2xl transition-colors duration-300">
                    <NavItem href="/staff/home" icon={<Home size={22} />} active={isActive('/staff/home')} />
                    <NavItem href="/staff/customers" icon={<User size={22} />} active={isActive('/staff/customers')} />

                    {/* Floating Action Button */}
                    <Link href="/staff/entry">
                        <div className="relative -top-8 mx-2 group">
                            <div className="absolute inset-0 bg-indigo-500 rounded-full blur opacity-40 group-hover:opacity-60 transition-opacity duration-500"></div>
                            <div className="w-16 h-16 bg-gradient-to-tr from-indigo-500 to-violet-600 rounded-full flex items-center justify-center text-white shadow-xl shadow-indigo-500/30 border-4 border-white dark:border-[#0f1115] transform group-active:scale-95 transition-all">
                                <Plus size={32} strokeWidth={3} />
                            </div>
                        </div>
                    </Link>

                    <NavItem href="/staff/history" icon={<History size={22} />} active={isActive('/staff/history')} />
                    <NavItem href="/staff/settings" icon={<Settings size={22} />} active={isActive('/staff/settings')} />
                </nav>
                <AnimatePresence>
                    {notifToast && (
                        <motion.div
                            initial={{ opacity: 0, y: -50, x: '-50%' }}
                            animate={{ opacity: 1, y: 0, x: '-50%' }}
                            exit={{ opacity: 0, y: -50, x: '-50%' }}
                            className="fixed top-6 left-1/2 z-[100] w-[90%] max-w-sm bg-[#1e293b] border border-white/10 text-white p-4 rounded-2xl shadow-2xl flex items-center gap-3 backdrop-blur-md"
                        >
                            <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center text-amber-500 shrink-0">
                                <span className="text-xl">🔔</span>
                            </div>
                            <div>
                                <p className="font-bold text-sm">New Notification</p>
                                <p className="text-xs text-slate-300">{notifToast}</p>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
}

function NavItem({ href, icon, active }: any) {
    return (
        <Link href={href} className="relative w-12 h-12 flex items-center justify-center">
            {active && (
                <motion.div
                    layoutId="nav-pill"
                    className="absolute inset-0 bg-slate-100 dark:bg-white/10 rounded-2xl"
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                />
            )}
            <span className={`relative z-10 transition-colors duration-300 ${active ? 'text-indigo-600 dark:text-white' : 'text-slate-400 dark:text-slate-400'}`}>
                {icon}
            </span>
        </Link>
    )
}
